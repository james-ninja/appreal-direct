(function($) {  

})(jQuery);